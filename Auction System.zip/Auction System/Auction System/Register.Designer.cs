﻿namespace Auction_System
{
    partial class Register
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usernameBox = new System.Windows.Forms.TextBox();
            this.passwordBox = new System.Windows.Forms.TextBox();
            this.firstnameBox = new System.Windows.Forms.TextBox();
            this.lastnameBox = new System.Windows.Forms.TextBox();
            this.emailBox = new System.Windows.Forms.TextBox();
            this.addressBox = new System.Windows.Forms.TextBox();
            this.submitBtn_reg = new System.Windows.Forms.Button();
            this.backBtn_reg = new System.Windows.Forms.Button();
            this.otpBox = new System.Windows.Forms.TextBox();
            this.secondEmailBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // usernameBox
            // 
            this.usernameBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.usernameBox.Location = new System.Drawing.Point(699, 37);
            this.usernameBox.Name = "usernameBox";
            this.usernameBox.PlaceholderText = "Username";
            this.usernameBox.Size = new System.Drawing.Size(571, 55);
            this.usernameBox.TabIndex = 0;
            // 
            // passwordBox
            // 
            this.passwordBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.passwordBox.Location = new System.Drawing.Point(699, 108);
            this.passwordBox.Name = "passwordBox";
            this.passwordBox.PasswordChar = '*';
            this.passwordBox.PlaceholderText = "Password";
            this.passwordBox.Size = new System.Drawing.Size(571, 55);
            this.passwordBox.TabIndex = 1;
            // 
            // firstnameBox
            // 
            this.firstnameBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.firstnameBox.Location = new System.Drawing.Point(699, 184);
            this.firstnameBox.Name = "firstnameBox";
            this.firstnameBox.PlaceholderText = "Firstname";
            this.firstnameBox.Size = new System.Drawing.Size(571, 55);
            this.firstnameBox.TabIndex = 2;
            // 
            // lastnameBox
            // 
            this.lastnameBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lastnameBox.Location = new System.Drawing.Point(699, 262);
            this.lastnameBox.Name = "lastnameBox";
            this.lastnameBox.PlaceholderText = "Lastname";
            this.lastnameBox.Size = new System.Drawing.Size(571, 55);
            this.lastnameBox.TabIndex = 3;
            // 
            // emailBox
            // 
            this.emailBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.emailBox.Location = new System.Drawing.Point(699, 334);
            this.emailBox.Name = "emailBox";
            this.emailBox.PlaceholderText = "Email";
            this.emailBox.Size = new System.Drawing.Size(571, 55);
            this.emailBox.TabIndex = 4;
            // 
            // addressBox
            // 
            this.addressBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.addressBox.Location = new System.Drawing.Point(699, 406);
            this.addressBox.Name = "addressBox";
            this.addressBox.PlaceholderText = "Address";
            this.addressBox.Size = new System.Drawing.Size(571, 55);
            this.addressBox.TabIndex = 5;
            // 
            // submitBtn_reg
            // 
            this.submitBtn_reg.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.submitBtn_reg.Location = new System.Drawing.Point(847, 572);
            this.submitBtn_reg.Name = "submitBtn_reg";
            this.submitBtn_reg.Size = new System.Drawing.Size(225, 69);
            this.submitBtn_reg.TabIndex = 6;
            this.submitBtn_reg.Text = "Submit";
            this.submitBtn_reg.UseVisualStyleBackColor = true;
            this.submitBtn_reg.Click += new System.EventHandler(this.submitBtn_reg_Click);
            // 
            // backBtn_reg
            // 
            this.backBtn_reg.Location = new System.Drawing.Point(12, 12);
            this.backBtn_reg.Name = "backBtn_reg";
            this.backBtn_reg.Size = new System.Drawing.Size(225, 69);
            this.backBtn_reg.TabIndex = 7;
            this.backBtn_reg.Text = "Back";
            this.backBtn_reg.UseVisualStyleBackColor = true;
            this.backBtn_reg.Click += new System.EventHandler(this.backBtn_reg_Click);
            // 
            // otpBox
            // 
            this.otpBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.otpBox.Location = new System.Drawing.Point(699, 493);
            this.otpBox.Name = "otpBox";
            this.otpBox.PlaceholderText = "One Time Passcode";
            this.otpBox.Size = new System.Drawing.Size(571, 55);
            this.otpBox.TabIndex = 8;
            this.otpBox.Visible = false;
            // 
            // secondEmailBox
            // 
            this.secondEmailBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.secondEmailBox.Location = new System.Drawing.Point(699, 493);
            this.secondEmailBox.Name = "secondEmailBox";
            this.secondEmailBox.PlaceholderText = "Enter Email Again";
            this.secondEmailBox.Size = new System.Drawing.Size(571, 55);
            this.secondEmailBox.TabIndex = 9;
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(20F, 48F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 977);
            this.Controls.Add(this.secondEmailBox);
            this.Controls.Add(this.otpBox);
            this.Controls.Add(this.backBtn_reg);
            this.Controls.Add(this.submitBtn_reg);
            this.Controls.Add(this.addressBox);
            this.Controls.Add(this.emailBox);
            this.Controls.Add(this.lastnameBox);
            this.Controls.Add(this.firstnameBox);
            this.Controls.Add(this.passwordBox);
            this.Controls.Add(this.usernameBox);
            this.MaximizeBox = false;
            this.Name = "Register";
            this.Text = "Register";
            this.Load += new System.EventHandler(this.Register_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox usernameBox;
        private TextBox passwordBox;
        private TextBox firstnameBox;
        private TextBox lastnameBox;
        private TextBox emailBox;
        private TextBox addressBox;
        private Button submitBtn_reg;
        private Button backBtn_reg;
        private TextBox otpBox;
        private TextBox secondEmailBox;
    }
}