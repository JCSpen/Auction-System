﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auction_System
{
    public partial class Menu : Form
    {
        public bool sellerscreen { get; set; }
        public bool support { get; set; }
        public bool refresh { get; set; }
        public dataController data = new dataController();
        public string itemname;
        public DateTime today = DateTime.Now.Date;
        public bool searched { get; set; }
        public Menu(string username)
        {
            InitializeComponent();
            displayHistory(username);
            displayWatchlist(username);
            refreshBid_Status(username);
            searched = false;
            usernameLbl.Text = username;
        }

        private void refreshBid_Status(string username)
        {
            data.auctionActivity(username);
        }
        private void displayHistory(string username)
        {
            data.viewHistory(historyData, username);
        }

        private void displayWatchlist(string username)
        {
            data.viewWatchlist(watchlistView,username);
        }

        private void sellerBtn_Click(object sender, EventArgs e)
        {
            sellerscreen = true;
            this.Close();
        }

        private void viewallBtn_Click(object sender, EventArgs e)
        {
            data.viewAll(listingView_Box);
        }

        private void searchbarBtn_Click(object sender, EventArgs e)
        {
            string entry = searchbarBox.Text;
            bool valid = validateInput();
            if (valid)
            {
                listingView_Box.Hide();
                productName_Box.Show();
                descriptionBox.Show();
                bidBox.Show();
                timeBox.Show();
                bidBtn.Show();
                watchlistBtn.Show();
                nameLbl.Show();
                descriptionLbl.Show();
                bidLbl.Show();
                timeLbl.Show();
                sellerName_Box.Show();
                productName_Box.Text = data.getName(entry);
                descriptionBox.Text = data.getDesc(entry);
                bidBox.Text = "£" + data.getBid(entry).ToString();
                if (bidBox.Text == "£0.0000")
                {
                    bidBox.Text = "£" + data.getInitial(entry);
                    bidLbl.Text = "Initial Bid:";
                    bidBtn.Text = "Bid with Initial";
                }
                if (data.getBuy(entry) != 0)
                {
                    buynowBox.Text = "£" + data.getBuy(entry).ToString();
                    buynowBtn.Show();
                    buynowBox.Show();
                    buyNowLbl.Show();

                }
                sellerName_Box.Text = data.getSeller(entry);
                timeLbl2.Show();
                timeBox.Text = data.getTime(entry).ToString() + " Days";
            }
        }

        private bool validateInput()
        {
            string input = searchbarBox.Text;
            string searchresult = data.getName(input);
            bool integer = false;
            bool exists = false;
            int error;
            if (int.TryParse(input, out error))
            {
                integer = true;
            }
            else
            {
                MessageBox.Show("Input is not an integer please re-enter");
            }
            if (searchresult != null)
            {
                exists = true;
            }
            else
            {
                MessageBox.Show("Product ID does not exist, Try Again");
            }

            if (exists && integer)
            {
                return true;
            }
            return false;
        }

        private void bidBtn_Click(object sender, EventArgs e)
        {
            string username = usernameLbl.Text;
            string entry = searchbarBox.Text;
            if (bidBtn.Text == "Bid (+£1.00)")
            {
                data.updateBid(entry, data.getBid(entry) + (decimal)1.00);
                bidBox.Text = "£" + data.getBid(entry).ToString();
                data.updateWinner(username, entry);
            }
            else
            {
                data.updateBid(entry,data.getInitial(entry));
                bidBox.Text= "£" + data.getBid(entry).ToString();
                bidBtn.Text = "Bid (+£1.00)";
                bidLbl.Text = "Current Bid:";
                data.updateWinner(username, entry);
            }
        }

        private void buynowBtn_Click(object sender, EventArgs e)
        {
            string username = usernameLbl.Text;
            string entry = searchbarBox.Text;
            data.buyItem(username,entry);
            data.viewHistory(historyData,username);
        }

        private void refreshBtn_Click(object sender, EventArgs e)
        {
            this.Close();
            refresh = true;
        }

        private void watchlistBtn_Click(object sender, EventArgs e)
        {
            string username = usernameLbl.Text;
            string entry = searchbarBox.Text;
            data.watchItem(entry, username);
            displayWatchlist(username);
        }

        private void supportBtn_Click(object sender, EventArgs e)
        {
            support = true;
            this.Close();
        }
    }
}
