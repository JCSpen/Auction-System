﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auction_System
{
    public partial class AdminMenu : Form
    {
        public bool refreshpage { get; set; }
        public dataController data = new dataController();
        public string table;
        public string column;
        public string value;
        public string query;
        public string identifier;
        public int ID;
        public AdminMenu()
        {
            InitializeComponent();
        }

        private void adminBtn_Click(object sender, EventArgs e)
        {
            if (passwordBox.Text == "Creator")
            {
                passwordBox.Hide();
                enterBtn.Hide();
                updateBtn.Show();
                columnBox.Show();
                valueBox.Show();
                deleteBox.Show();
                adminView.Show();
                accountsBtn.Show();
                historyBtn.Show();
                listingBtn.Show();
                suspendedView.Show();
                deleteBtn.Show();
                suspensionID_Box.Show();
                suspendBtn.Show();
                reactivateBtn.Show();
                strikeBtn.Show();
                getSuspensions();
                getAccounts();
            }
            else
            {
                MessageBox.Show("Incorrect Password");
            }
        }

        private void getSuspensions()
        {
            query = "SELECT * FROM Suspensions";
            data.updateSuspension(query, suspendedView);
        }

        private void accountsBtn_Click(object sender, EventArgs e)
        {
           getAccounts();
        }

        private void listingBtn_Click(object sender, EventArgs e)
        {
            table = "Listings";
            column = "Listing_Id";
            identifier = "Listing_Id";
            adminView.DataSource = null;
            adminView.Refresh();
            data.viewAll(adminView);
        }

        private void historyBtn_Click(object sender, EventArgs e)
        {
            table = "History";
            column = "Listing_Id";
            identifier = "Listing_Id";
            adminView.DataSource = null;
            adminView.Refresh();
            string username = "Admin";
            data.viewHistory(adminView, username);
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            value = deleteBox.Text;
            query = "DELETE FROM " + table + " WHERE " + column + " = " + value;
            data.updateTable(query); 
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            column = columnBox.Text;
            value = valueBox.Text;
            ID = int.Parse(deleteBox.Text);
            query = "UPDATE " + table + " SET " + "["+ column + "]"+ " = '" + value + "' WHERE " + identifier + " = " + ID + ";";
            data.updateTable(query);
            
        }
        private void getAccounts()
        {
            table = "Accounts";
            column = "ID";
            identifier = "ID";
            data.viewAccounts(adminView);
        }

        private void strikeBtn_Click(object sender, EventArgs e)
        {
            data.addStrike(suspensionID_Box.Text);
            refresh();
        }

        private void reactivateBtn_Click(object sender, EventArgs e)
        {
            data.reActivate(suspensionID_Box.Text);
            refresh();
        }

        private void suspendBtn_Click(object sender, EventArgs e)
        {
            data.suspendAccount(suspensionID_Box.Text);
            refresh();
        }

        private void refresh()
        {
            refreshpage = true;
            this.Close();
        }
    }
}
