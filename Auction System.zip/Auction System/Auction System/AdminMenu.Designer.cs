﻿namespace Auction_System
{
    partial class AdminMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.passwordBox = new System.Windows.Forms.TextBox();
            this.enterBtn = new System.Windows.Forms.Button();
            this.adminView = new System.Windows.Forms.DataGridView();
            this.accountsBtn = new System.Windows.Forms.Button();
            this.listingBtn = new System.Windows.Forms.Button();
            this.historyBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.deleteBox = new System.Windows.Forms.TextBox();
            this.columnBox = new System.Windows.Forms.TextBox();
            this.updateBtn = new System.Windows.Forms.Button();
            this.valueBox = new System.Windows.Forms.TextBox();
            this.suspendedView = new System.Windows.Forms.DataGridView();
            this.suspensionID_Box = new System.Windows.Forms.TextBox();
            this.strikeBtn = new System.Windows.Forms.Button();
            this.reactivateBtn = new System.Windows.Forms.Button();
            this.suspendBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.adminView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.suspendedView)).BeginInit();
            this.SuspendLayout();
            // 
            // passwordBox
            // 
            this.passwordBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.passwordBox.Location = new System.Drawing.Point(752, 36);
            this.passwordBox.Name = "passwordBox";
            this.passwordBox.Size = new System.Drawing.Size(300, 55);
            this.passwordBox.TabIndex = 0;
            this.passwordBox.Text = "Password";
            // 
            // enterBtn
            // 
            this.enterBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.enterBtn.Location = new System.Drawing.Point(797, 123);
            this.enterBtn.Name = "enterBtn";
            this.enterBtn.Size = new System.Drawing.Size(225, 69);
            this.enterBtn.TabIndex = 1;
            this.enterBtn.Text = "Submit";
            this.enterBtn.UseVisualStyleBackColor = true;
            this.enterBtn.Click += new System.EventHandler(this.adminBtn_Click);
            // 
            // adminView
            // 
            this.adminView.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.adminView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adminView.Location = new System.Drawing.Point(12, 123);
            this.adminView.Name = "adminView";
            this.adminView.RowHeadersWidth = 123;
            this.adminView.RowTemplate.Height = 57;
            this.adminView.Size = new System.Drawing.Size(734, 659);
            this.adminView.TabIndex = 2;
            this.adminView.Visible = false;
            // 
            // accountsBtn
            // 
            this.accountsBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.accountsBtn.Location = new System.Drawing.Point(12, 36);
            this.accountsBtn.Name = "accountsBtn";
            this.accountsBtn.Size = new System.Drawing.Size(225, 69);
            this.accountsBtn.TabIndex = 3;
            this.accountsBtn.Text = "Accounts";
            this.accountsBtn.UseVisualStyleBackColor = true;
            this.accountsBtn.Visible = false;
            this.accountsBtn.Click += new System.EventHandler(this.accountsBtn_Click);
            // 
            // listingBtn
            // 
            this.listingBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.listingBtn.Location = new System.Drawing.Point(268, 36);
            this.listingBtn.Name = "listingBtn";
            this.listingBtn.Size = new System.Drawing.Size(225, 69);
            this.listingBtn.TabIndex = 4;
            this.listingBtn.Text = "Listings";
            this.listingBtn.UseVisualStyleBackColor = true;
            this.listingBtn.Visible = false;
            this.listingBtn.Click += new System.EventHandler(this.listingBtn_Click);
            // 
            // historyBtn
            // 
            this.historyBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.historyBtn.Location = new System.Drawing.Point(521, 36);
            this.historyBtn.Name = "historyBtn";
            this.historyBtn.Size = new System.Drawing.Size(225, 69);
            this.historyBtn.TabIndex = 5;
            this.historyBtn.Text = "History";
            this.historyBtn.UseVisualStyleBackColor = true;
            this.historyBtn.Visible = false;
            this.historyBtn.Click += new System.EventHandler(this.historyBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.deleteBtn.Location = new System.Drawing.Point(400, 806);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(346, 62);
            this.deleteBtn.TabIndex = 6;
            this.deleteBtn.Text = "Delete Row";
            this.deleteBtn.UseVisualStyleBackColor = true;
            this.deleteBtn.Visible = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // deleteBox
            // 
            this.deleteBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.deleteBox.Location = new System.Drawing.Point(12, 797);
            this.deleteBox.Name = "deleteBox";
            this.deleteBox.PlaceholderText = "Insert ID Number";
            this.deleteBox.Size = new System.Drawing.Size(346, 55);
            this.deleteBox.TabIndex = 7;
            this.deleteBox.Visible = false;
            // 
            // columnBox
            // 
            this.columnBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.columnBox.Location = new System.Drawing.Point(12, 858);
            this.columnBox.Name = "columnBox";
            this.columnBox.PlaceholderText = "Insert Column Name";
            this.columnBox.Size = new System.Drawing.Size(346, 55);
            this.columnBox.TabIndex = 8;
            this.columnBox.Visible = false;
            // 
            // updateBtn
            // 
            this.updateBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.updateBtn.Location = new System.Drawing.Point(400, 891);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(346, 62);
            this.updateBtn.TabIndex = 9;
            this.updateBtn.Text = "Update Row";
            this.updateBtn.UseVisualStyleBackColor = true;
            this.updateBtn.Visible = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // valueBox
            // 
            this.valueBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.valueBox.Location = new System.Drawing.Point(12, 919);
            this.valueBox.Name = "valueBox";
            this.valueBox.PlaceholderText = "Insert Value";
            this.valueBox.Size = new System.Drawing.Size(346, 55);
            this.valueBox.TabIndex = 10;
            this.valueBox.Visible = false;
            // 
            // suspendedView
            // 
            this.suspendedView.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.suspendedView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.suspendedView.Location = new System.Drawing.Point(1138, 123);
            this.suspendedView.Name = "suspendedView";
            this.suspendedView.RowHeadersWidth = 123;
            this.suspendedView.RowTemplate.Height = 57;
            this.suspendedView.Size = new System.Drawing.Size(734, 660);
            this.suspendedView.TabIndex = 11;
            this.suspendedView.Visible = false;
            // 
            // suspensionID_Box
            // 
            this.suspensionID_Box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.suspensionID_Box.Location = new System.Drawing.Point(1138, 813);
            this.suspensionID_Box.Name = "suspensionID_Box";
            this.suspensionID_Box.PlaceholderText = "Insert ID Number";
            this.suspensionID_Box.Size = new System.Drawing.Size(346, 55);
            this.suspensionID_Box.TabIndex = 12;
            this.suspensionID_Box.Visible = false;
            // 
            // strikeBtn
            // 
            this.strikeBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.strikeBtn.Location = new System.Drawing.Point(1526, 806);
            this.strikeBtn.Name = "strikeBtn";
            this.strikeBtn.Size = new System.Drawing.Size(346, 62);
            this.strikeBtn.TabIndex = 13;
            this.strikeBtn.Text = "Add Strike";
            this.strikeBtn.UseVisualStyleBackColor = true;
            this.strikeBtn.Visible = false;
            this.strikeBtn.Click += new System.EventHandler(this.strikeBtn_Click);
            // 
            // reactivateBtn
            // 
            this.reactivateBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.reactivateBtn.Location = new System.Drawing.Point(1526, 891);
            this.reactivateBtn.Name = "reactivateBtn";
            this.reactivateBtn.Size = new System.Drawing.Size(346, 62);
            this.reactivateBtn.TabIndex = 14;
            this.reactivateBtn.Text = "Re-Activate";
            this.reactivateBtn.UseVisualStyleBackColor = true;
            this.reactivateBtn.Visible = false;
            this.reactivateBtn.Click += new System.EventHandler(this.reactivateBtn_Click);
            // 
            // suspendBtn
            // 
            this.suspendBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.suspendBtn.Location = new System.Drawing.Point(1138, 891);
            this.suspendBtn.Name = "suspendBtn";
            this.suspendBtn.Size = new System.Drawing.Size(346, 62);
            this.suspendBtn.TabIndex = 15;
            this.suspendBtn.Text = "Suspend";
            this.suspendBtn.UseVisualStyleBackColor = true;
            this.suspendBtn.Visible = false;
            this.suspendBtn.Click += new System.EventHandler(this.suspendBtn_Click);
            // 
            // AdminMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(20F, 48F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 977);
            this.Controls.Add(this.suspendBtn);
            this.Controls.Add(this.reactivateBtn);
            this.Controls.Add(this.strikeBtn);
            this.Controls.Add(this.suspensionID_Box);
            this.Controls.Add(this.suspendedView);
            this.Controls.Add(this.valueBox);
            this.Controls.Add(this.updateBtn);
            this.Controls.Add(this.columnBox);
            this.Controls.Add(this.deleteBox);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.historyBtn);
            this.Controls.Add(this.listingBtn);
            this.Controls.Add(this.accountsBtn);
            this.Controls.Add(this.adminView);
            this.Controls.Add(this.enterBtn);
            this.Controls.Add(this.passwordBox);
            this.DoubleBuffered = true;
            this.MaximizeBox = false;
            this.Name = "AdminMenu";
            this.Text = "AdminMenu";
            ((System.ComponentModel.ISupportInitialize)(this.adminView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.suspendedView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox passwordBox;
        private Button enterBtn;
        private DataGridView adminView;
        private Button accountsBtn;
        private Button listingBtn;
        private Button historyBtn;
        private Button deleteBtn;
        private TextBox deleteBox;
        private TextBox columnBox;
        private Button updateBtn;
        private TextBox valueBox;
        private DataGridView suspendedView;
        private TextBox suspensionID_Box;
        private Button strikeBtn;
        private Button reactivateBtn;
        private Button suspendBtn;
    }
}