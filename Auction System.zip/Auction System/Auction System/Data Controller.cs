﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace Auction_System
{
    public class dataController
    {
        //Variables
        public OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.Oledb.12.0;Data Source=AuctionSystem.accdb"); //Source
        public OleDbDataAdapter da = new OleDbDataAdapter();
        public OleDbCommand cmd = new OleDbCommand();
        public DataSet ds = new DataSet();
        public DateTime today = DateTime.Now.Date;
        public DataTable History = new DataTable();
        public DataTable Listings = new DataTable();
        public DataTable Watchlist = new DataTable();
        public DataTable Accounts = new DataTable();
        public DataTable Suspensions = new DataTable();
        public List<string> productInfo = new List<string>();
        //public UpdateSQL SQL = new UpdateSQL();

        //Used for registration purposes
        public void regData(string username, string password, string firstname, string lastname, string email, string address)
        {
            con.Open();
            string query = "INSERT INTO Accounts (Username,[Password],Firstname,Lastname,Email,Address,Verified) VALUES (@Username,@Password,@Firstname,@Lastname,@Email,@Address,'Yes');";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password", password);
            cmd.Parameters.AddWithValue("@Firstname", firstname);
            cmd.Parameters.AddWithValue("@Lastname", lastname);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Address", address);
            cmd.ExecuteNonQuery();
            con.Close();
            regSuspension(username);
        }
        public bool checkData(string username, string password)
        {
            con.Open();
            string query = "SELECT [Password] FROM Accounts WHERE Username = @Username";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.CommandType = CommandType.Text;
            string? getResult = (string)cmd.ExecuteScalar();
            string result = getResult;
            if (getResult != null)
            {
                if (result == password)
                { 
                    return true;
                }
            }
            con.Close();
            return false;
        }


        public void newListing(string name, string description, decimal startBid, DateTime time, decimal setprice, string buynow, string username, string auctiontime, int listingID)
        {
            con.Open();
            string query = "INSERT INTO LISTINGS (Listing_Id,ItemName,Description,BuyNowPrice,BuyNowStatus,CurrentBid,InitialBid,DateListed,SellerUsername,AuctionEnds) VALUES (@ID,@Name,@Description,@Buynow,@Status,@Currentbid,@Startbid,@Time,@Username,@Ends);";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ID", listingID);
            cmd.Parameters.AddWithValue("@Name", name);
            cmd.Parameters.AddWithValue("@Description", description);
            cmd.Parameters.AddWithValue("@Buynow", setprice);
            cmd.Parameters.AddWithValue("@Status", buynow);
            cmd.Parameters.AddWithValue("@Currentbid", "0");
            cmd.Parameters.AddWithValue("@Startbid", startBid);
            cmd.Parameters.AddWithValue("@Time", time);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Ends", time.AddDays(int.Parse(auctiontime)));
            cmd.ExecuteNonQuery(); //   WRONG DATATYPE
            con.Close();
        }
        public void viewAll(DataGridView ListingViewer)
        {
            if (ListingViewer != null)
            {
                Listings.Clear();
                ListingViewer.DataSource = null;
            }
            string query = "SELECT * FROM LISTINGS";
            con.Open();
            cmd = new OleDbCommand(query, con);
            da = new OleDbDataAdapter(cmd);
            da.Fill(Listings);
            ListingViewer.DataSource = Listings;
            con.Close();
        }

        public void updateTable(string query)
        {
            con.Open();
            cmd = new OleDbCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void updateSuspension(string query, DataGridView Suspension)
        {
            con.Open();
            cmd = new OleDbCommand(query, con);
            da = new OleDbDataAdapter(cmd);
            da.Fill(Suspensions);
            Suspension.DataSource = Suspensions;
            con.Close();
        }

        public void viewAccounts(DataGridView AccountData)
        {
            if (AccountData != null)
            {
                Accounts.Clear();
                AccountData.DataSource = null;
            }
            string query = "SELECT * FROM ACCOUNTS";
            con.Open();
            cmd = new OleDbCommand(query, con);
            da = new OleDbDataAdapter(cmd);
            da.Fill(Accounts);
            AccountData.DataSource = Accounts;
            con.Close();
        }
        public void viewWatchlist(DataGridView watchedItems, string username)
        {
            string query = "SELECT Listing_Id FROM Watchlist WHERE Username = @NAME";
            con.Open();
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@NAME", username);
            da = new OleDbDataAdapter(cmd);
            da.Fill(Watchlist);
            watchedItems.DataSource = Watchlist;
            con.Close();
        }

        public void viewHistory(DataGridView HistoryView, string username)
        {
            if (HistoryView != null)
            {
                History.Clear();
                HistoryView.DataSource = null;
            }
            if (username == "Admin")
            {
                string query = "SELECT * FROM History";
                con.Open();
                OleDbCommand cmd = new OleDbCommand(query, con);
                da = new OleDbDataAdapter(cmd);
                da.Fill(History);
                HistoryView.DataSource = History;
                con.Close();
            }
            else
            {
                string query = "SELECT Listing_Id,Price_Paid,Date_Bought FROM History WHERE Buyer_Name = @Name";
                con.Open();
                cmd = new OleDbCommand(query, con);
                cmd.Parameters.AddWithValue("@Name", username);
                da = new OleDbDataAdapter(cmd);
                da.Fill(History);
                HistoryView.DataSource = History;
                con.Close();
            }
        }
        public string getName(string entry)
        {
            string query = "SELECT ItemName FROM Listings WHERE Listing_Id = @ENTRY";
            con.Open();
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ENTRY", entry);
            cmd.CommandType = CommandType.Text;
            string? getResult = (string)cmd.ExecuteScalar();
            string result = getResult;
            con.Close();
            return result;
        }
        public string getDesc(string entry)
        {
            string query = "SELECT Description FROM Listings WHERE Listing_Id = @ENTRY";
            con.Open();
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ENTRY", entry);
            cmd.CommandType = CommandType.Text;
            string? getResult = (string)cmd.ExecuteScalar();
            string result = getResult;
            con.Close();
            return result;
        }

        public decimal getBid(string entry)
        {
            string query = "SELECT CurrentBid FROM Listings WHERE Listing_Id = @ENTRY";
            con.Open();
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ENTRY", entry);
            OleDbDataReader reader = cmd.ExecuteReader();
            decimal result = 0;
            if (reader.HasRows == true)
            {
                while (reader.Read())
                {
                    if (reader["currentBid"] != null && reader["currentBid"] != DBNull.Value)
                    {
                        result = (decimal)(reader.GetValue(0));
                    }
                }
            }
            con.Close();
            return result;
        }
        public decimal getBuy(string entry)
        {
            string query = "SELECT BuyNowPrice FROM Listings WHERE Listing_Id = @ENTRY";
            con.Open();
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ENTRY", entry);
            OleDbDataReader reader = cmd.ExecuteReader();
            decimal result = 0;
            if (reader.HasRows == true)
            {
                while (reader.Read())
                {
                    if (reader["BuyNowPrice"] != null && reader["BuyNowPrice"] != DBNull.Value)
                    {
                        result = (decimal)(reader.GetValue(0));
                    }
                }
            }
            con.Close();
            return result;
        }
        public void updateWinner(string username, string entry)
        {
            string query = "UPDATE Listings SET WinningUser = @User WHERE Listing_ID = @ID";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@User", username);
            cmd.Parameters.AddWithValue("@ID", entry);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
        public int getTime(string entry)
        {
            string query = "SELECT DateListed FROM Listings WHERE Listing_Id = @ENTRY";
            con.Open();
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ENTRY", entry);
            cmd.CommandType = CommandType.Text;
            DateTime dateListed = (DateTime)cmd.ExecuteScalar();
            query = "SELECT AuctionEnds FROM Listings WHERE Listing_Id = @ENTRY";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ENTRY", entry);
            cmd.CommandType = CommandType.Text;
            DateTime auctionEnds = (DateTime)cmd.ExecuteScalar();
            con.Close();
            int Result = (auctionEnds - dateListed).Days;
            return Result;
        }

        public decimal getInitial(string entry)
        {
            string query = "SELECT InitialBid FROM Listings WHERE Listing_Id = @ENTRY";
            con.Open();
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ENTRY", entry);
            OleDbDataReader reader = cmd.ExecuteReader();
            decimal result = 0;
            if (reader.HasRows == true)
            {
                while (reader.Read())
                {
                    if (reader["InitialBid"] != null && reader["InitialBid"] != DBNull.Value)
                    {
                        result = (decimal)reader.GetValue(0);
                    }
                }

            }
            con.Close();
            return result;
        }

        public string getSeller(string entry)
        {
            string query = "SELECT SellerUsername FROM Listings WHERE Listing_Id = @ENTRY";
            con.Open();
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ENTRY", entry);
            cmd.CommandType = CommandType.Text;
            string result = (string)cmd.ExecuteScalar();
            con.Close();
            return result;
        }
        public void updateBid(string entry, decimal bid)
        {
            string query;
            // DATATYPE NOT WORKING
            query = "UPDATE Listings SET CurrentBid = @NEW WHERE Listing_Id = @ENTRY";
            con.Open();
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@NEW", bid);
            cmd.Parameters.AddWithValue("ENTRY", entry);
            cmd.ExecuteNonQuery();
            con.Close();

        }

        public void buyItem(string username, string entry)
        {
            string query = "SELECT BuyNowPrice FROM Listings WHERE Listing_Id = @ENTRY";
            con.Open();
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ENTRY", entry);
            OleDbDataReader reader = cmd.ExecuteReader();
            decimal result = 0;
            if (reader.HasRows == true)
            {
                while (reader.Read())
                {
                    if (reader["BuyNowPrice"] != null && reader["BuyNowPrice"] != DBNull.Value)
                    {
                        result = (decimal)(reader.GetValue(0));
                    }
                }
            }
            reader.Close();
            con.Close();
            addHistory(entry, username, result);
            con.Close();
            bool buynow = true;
            dropListing(entry);

        }

        private void addHistory(string entry, string username, decimal price)
        {
            con.Open();
            string query = "INSERT INTO History(Listing_Id,Buyer_Name,Price_Paid,Date_Bought) VALUES (@ID,@NAME,@PRICE,@DATE)";
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ID", entry);
            cmd.Parameters.AddWithValue("@NAME", username);
            cmd.Parameters.AddWithValue("@PRICE", price);
            cmd.Parameters.AddWithValue("@DATE", today);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void dropListing(string entry)
        {
            string query = "DELETE FROM Listings WHERE Listing_ID = @ENTRY"; ;
            con.Open();
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ENTRY", entry);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void watchItem(string entry, string username)
        {
            string query = "INSERT INTO Watchlist(Listing_ID,Username) VALUES (@ID,@NAME)";
            con.Open();
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@ID", entry);
            cmd.Parameters.AddWithValue("@NAME", username);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void regSuspension(string username)
        {
            string query = "INSERT INTO Suspensions(Strikes,NumSuspensions,Status,Username) VALUES ('0','0','Active',@NAME);";
            con.Open();
            cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@NAME", username);
            cmd.ExecuteNonQuery();
            con.Close();

        }

        public void auctionActivity(string username)
        {
            string query = "SELECT Listing_Id FROM Listings WHERE AuctionEnds <= #" + today.Date.ToString() + "# AND WinningUser = '" + username + "';";
            cmd = new OleDbCommand(query, con);
            con.Open();
            OleDbDataReader reader = cmd.ExecuteReader();
            bool buynow = false;
            string result;
            int index = 0;
            if (reader.HasRows == true)
            {
                while (reader.Read())
                {
                    if (index > 0)
                    {
                        con.Open();
                    }
                    if (reader["Listing_Id"] != null && reader["Listing_Id"] != DBNull.Value)
                    {
                        int ID = (int)(reader.GetValue(index));
                        result = ID.ToString();
                        con.Close();
                        addHistory(result, username, getBid(result));
                        dropListing(result.ToString());
                        index++;
                        MessageBox.Show("Congrats you won: " + result);
                        con.Open();
                    }
                    else
                    {
                        expiredListings();
                        con.Open();
                    }
                }
                
            }
            con.Close();
            

        }

        private void expiredListings()
        {
            string query = "SELECT Listing_Id FROM Listings WHERE AuctionEnds = #" + today.Date.ToString() + "# OR AuctionEnds < #" + today.Date.ToString() + "#;";
            cmd = new OleDbCommand(query, con);
            con.Open();
            OleDbDataReader reader = cmd.ExecuteReader();
            string result;
            int index = 0;
            if (reader.HasRows == true)
            {
                while (reader.Read())
                {
                    if (reader["Listing_Id"] != null && reader["Listing_Id"] != DBNull.Value)
                    {
                        int ID = (int)(reader.GetValue(index));
                        result = ID.ToString();
                        con.Close();
                        dropListing(result);
                        con.Open();
                        index++;
                    }
                }
            }
            con.Close();
            

        }

        public string getEmail(string username)
        {
            string query = "SELECT Email from Accounts WHERE Username = '" + username + "';";
            cmd = new OleDbCommand(query, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            string result = (string)cmd.ExecuteScalar();
            con.Close();
            return result;
        }

        private int getStrikes(string ID)
        {
            string query = "SELECT Strikes FROM Suspensions WHERE ID = " + ID + ";";
            cmd = new OleDbCommand(query, con);
            con.Open();
            string result = (string)cmd.ExecuteScalar();
            con.Close();
            return int.Parse(result);
        }

        public void addStrike(string ID)
        {
            int newStrikes = getStrikes(ID) + 1;
            if(newStrikes >= 3)
            {
                newStrikes = 0;
                suspendAccount(ID);
                MessageBox.Show("Account Suspended due to 3 or more strikes");
            }
            string query = "UPDATE Suspensions SET Strikes = " + newStrikes + " WHERE ID = " + ID + ";";
            cmd = new OleDbCommand(query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void reActivate(string ID)
        {
            string query = "UPDATE Suspensions SET Status = 'Active' WHERE ID = " + ID + ";";
            cmd = new OleDbCommand(query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private int getSuspensions(string ID)
        {
            string query = "SELECT NumSuspensions FROM Suspensions WHERE ID = " + ID + ";";
            cmd = new OleDbCommand(query, con);
            con.Open();
            string result = (string)cmd.ExecuteScalar();
            con.Close();
            return int.Parse(result);
        }

        public void suspendAccount(string ID)
        {
            int newSuspensions = getSuspensions(ID) + 1;
            string query = "UPDATE Suspensions SET NumSuspensions = " + newSuspensions + " WHERE ID = " + ID + ";";
            cmd = new OleDbCommand(query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            deActivate(ID);
        }
        public void deActivate(string ID)
        {
            string query = "UPDATE Suspensions SET Status = 'Suspended' WHERE ID = " + ID + ";";
            cmd = new OleDbCommand(query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public bool getStatus(string Username)
        {
            string query = "SELECT Status FROM Suspensions WHERE Username = '" + Username + "';";
            cmd = new OleDbCommand(query, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            string result = (string)cmd.ExecuteScalar();
            con.Close();
            if (result != "Active")
            {
                return true;
            }
            return false;
        }


    }
}

