﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auction_System
{
    public partial class Login : Form
    {
        public bool regscreen { get; set; }
        public bool menuscreen { get; set; }

        public bool adminscreen { get; set; }
        public string username { get; set; }

        public bool support { get; set; }

        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void newuserLbl_Click(object sender, EventArgs e)
        {
            regscreen = true;
            this.Close();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            dataController data = new dataController();
            bool suspended = data.getStatus(usernameBox.Text);
            if (!suspended)
            {
                bool valid = data.checkData(usernameBox.Text, passwordBox.Text);
                if (valid == true)
                {
                    menuscreen = true;
                    username = usernameBox.Text;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Incorrect Username or Password");
                }
            }
            else
            {
                MessageBox.Show("Account is Suspended. You will be transfered to the Appeal Page");
                support = true;
                username = usernameBox.Text;
                this.Close();
            }
            
        }

        private void adminBtn_Click(object sender, EventArgs e)
        {
            adminscreen = true;
            this.Close();
        }
    }
}
