﻿using System;
using System.Net;
using System.Net.Mail;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auction_System
{
    public partial class CustomerSupport : Form
    {
        public dataController data = new dataController();
        public string to, from, pass, mail;
        public string name;
        
        public CustomerSupport(string username)
        {
            InitializeComponent();
            name = username;
        }

        private void CustomerSupport_Load(object sender, EventArgs e)
        {
            MessageBox.Show("We are sorry to hear that you are having issues, please submit a ticket so our Administrators can solve it. **NOTE THAT FALSE ACCUSATIONS OR SPAMMING WILL RESULT IN BANS!");
        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            sendConfirmation();
            sendTicket();
            this.Close();
        }

        private void sendConfirmation()
        {
            to = data.getEmail(name);
            from = "systemauction44@gmail.com";
            pass = "Creator1";
            MailMessage message = new MailMessage();
            message.To.Add(to);
            message.From = new MailAddress(from);
            message.Body = "Copy of your ticket : " + issueBox.Text;
            message.Subject = "Ticket Confirmation";
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.EnableSsl = true;
            smtp.Port = 587;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential(from, pass);
            sendEmail(smtp, message);
        }

        private void sendTicket()
        {
            to = "systemauction44@gmail.com";
            from = "systemauction44@gmail.com";
            pass = "Creator1";
            MailMessage message = new MailMessage();
            message.To.Add(to);
            message.From = new MailAddress(from);
            message.Body = "User Issue : " + issueBox.Text;
            message.Subject = "Customer Ticket";
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.EnableSsl = true;
            smtp.Port = 587;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential(from, pass);
            sendEmail(smtp, message);
        }

        private void sendEmail(SmtpClient smtp, MailMessage message)
        {
            if (smtp != null)
            {
                try
                {
                    smtp.Send(message);
                    MessageBox.Show("Sent");
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Error");
                }
            }
        }
    }
}
