﻿namespace Auction_System
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchbarBox = new System.Windows.Forms.TextBox();
            this.searchbarBtn = new System.Windows.Forms.Button();
            this.sellerBtn = new System.Windows.Forms.Button();
            this.listingView_Box = new System.Windows.Forms.DataGridView();
            this.viewallBtn = new System.Windows.Forms.Button();
            this.productName_Box = new System.Windows.Forms.TextBox();
            this.descriptionBox = new System.Windows.Forms.TextBox();
            this.bidBox = new System.Windows.Forms.TextBox();
            this.buynowBox = new System.Windows.Forms.TextBox();
            this.sellerName_Box = new System.Windows.Forms.TextBox();
            this.bidBtn = new System.Windows.Forms.Button();
            this.buynowBtn = new System.Windows.Forms.Button();
            this.watchlistBtn = new System.Windows.Forms.Button();
            this.timeLbl = new System.Windows.Forms.Label();
            this.timeBox = new System.Windows.Forms.TextBox();
            this.descriptionLbl = new System.Windows.Forms.Label();
            this.bidLbl = new System.Windows.Forms.Label();
            this.buyNowLbl = new System.Windows.Forms.Label();
            this.nameLbl = new System.Windows.Forms.Label();
            this.timeLbl2 = new System.Windows.Forms.Label();
            this.userLbl = new System.Windows.Forms.Label();
            this.usernameLbl = new System.Windows.Forms.Label();
            this.historyLbl = new System.Windows.Forms.Label();
            this.historyData = new System.Windows.Forms.DataGridView();
            this.refreshBtn = new System.Windows.Forms.Button();
            this.watchlistView = new System.Windows.Forms.DataGridView();
            this.watchlist_lbl = new System.Windows.Forms.Label();
            this.supportBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.listingView_Box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.historyData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.watchlistView)).BeginInit();
            this.SuspendLayout();
            // 
            // searchbarBox
            // 
            this.searchbarBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.searchbarBox.Location = new System.Drawing.Point(429, 26);
            this.searchbarBox.Name = "searchbarBox";
            this.searchbarBox.PlaceholderText = "Enter Product ID to View a Product";
            this.searchbarBox.Size = new System.Drawing.Size(936, 55);
            this.searchbarBox.TabIndex = 0;
            // 
            // searchbarBtn
            // 
            this.searchbarBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.searchbarBtn.Location = new System.Drawing.Point(1208, 26);
            this.searchbarBtn.Name = "searchbarBtn";
            this.searchbarBtn.Size = new System.Drawing.Size(225, 55);
            this.searchbarBtn.TabIndex = 1;
            this.searchbarBtn.Text = "Search";
            this.searchbarBtn.UseVisualStyleBackColor = true;
            this.searchbarBtn.Click += new System.EventHandler(this.searchbarBtn_Click);
            // 
            // sellerBtn
            // 
            this.sellerBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.sellerBtn.Location = new System.Drawing.Point(12, 969);
            this.sellerBtn.Name = "sellerBtn";
            this.sellerBtn.Size = new System.Drawing.Size(323, 67);
            this.sellerBtn.TabIndex = 2;
            this.sellerBtn.Text = "Login as Seller";
            this.sellerBtn.UseVisualStyleBackColor = true;
            this.sellerBtn.Click += new System.EventHandler(this.sellerBtn_Click);
            // 
            // listingView_Box
            // 
            this.listingView_Box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.listingView_Box.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.listingView_Box.Location = new System.Drawing.Point(429, 110);
            this.listingView_Box.Name = "listingView_Box";
            this.listingView_Box.ReadOnly = true;
            this.listingView_Box.RowHeadersWidth = 123;
            this.listingView_Box.RowTemplate.Height = 57;
            this.listingView_Box.Size = new System.Drawing.Size(1004, 808);
            this.listingView_Box.TabIndex = 3;
            // 
            // viewallBtn
            // 
            this.viewallBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.viewallBtn.Location = new System.Drawing.Point(365, 969);
            this.viewallBtn.Name = "viewallBtn";
            this.viewallBtn.Size = new System.Drawing.Size(339, 69);
            this.viewallBtn.TabIndex = 4;
            this.viewallBtn.Text = "View All Listings";
            this.viewallBtn.UseVisualStyleBackColor = true;
            this.viewallBtn.Click += new System.EventHandler(this.viewallBtn_Click);
            // 
            // productName_Box
            // 
            this.productName_Box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.productName_Box.Location = new System.Drawing.Point(446, 124);
            this.productName_Box.Name = "productName_Box";
            this.productName_Box.Size = new System.Drawing.Size(958, 55);
            this.productName_Box.TabIndex = 5;
            this.productName_Box.Visible = false;
            // 
            // descriptionBox
            // 
            this.descriptionBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.descriptionBox.Location = new System.Drawing.Point(447, 233);
            this.descriptionBox.Multiline = true;
            this.descriptionBox.Name = "descriptionBox";
            this.descriptionBox.Size = new System.Drawing.Size(958, 145);
            this.descriptionBox.TabIndex = 6;
            this.descriptionBox.Visible = false;
            // 
            // bidBox
            // 
            this.bidBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bidBox.Location = new System.Drawing.Point(446, 432);
            this.bidBox.Name = "bidBox";
            this.bidBox.Size = new System.Drawing.Size(958, 55);
            this.bidBox.TabIndex = 7;
            this.bidBox.Visible = false;
            // 
            // buynowBox
            // 
            this.buynowBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.buynowBox.Location = new System.Drawing.Point(446, 541);
            this.buynowBox.Name = "buynowBox";
            this.buynowBox.Size = new System.Drawing.Size(958, 55);
            this.buynowBox.TabIndex = 8;
            this.buynowBox.Visible = false;
            // 
            // sellerName_Box
            // 
            this.sellerName_Box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.sellerName_Box.Location = new System.Drawing.Point(446, 662);
            this.sellerName_Box.Name = "sellerName_Box";
            this.sellerName_Box.Size = new System.Drawing.Size(958, 55);
            this.sellerName_Box.TabIndex = 9;
            this.sellerName_Box.Visible = false;
            // 
            // bidBtn
            // 
            this.bidBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bidBtn.Location = new System.Drawing.Point(447, 849);
            this.bidBtn.Name = "bidBtn";
            this.bidBtn.Size = new System.Drawing.Size(288, 69);
            this.bidBtn.TabIndex = 10;
            this.bidBtn.Text = "Bid (+£1.00)";
            this.bidBtn.UseVisualStyleBackColor = true;
            this.bidBtn.Visible = false;
            this.bidBtn.Click += new System.EventHandler(this.bidBtn_Click);
            // 
            // buynowBtn
            // 
            this.buynowBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.buynowBtn.Location = new System.Drawing.Point(778, 849);
            this.buynowBtn.Name = "buynowBtn";
            this.buynowBtn.Size = new System.Drawing.Size(300, 69);
            this.buynowBtn.TabIndex = 11;
            this.buynowBtn.Text = "Buy Now";
            this.buynowBtn.UseVisualStyleBackColor = true;
            this.buynowBtn.Visible = false;
            this.buynowBtn.Click += new System.EventHandler(this.buynowBtn_Click);
            // 
            // watchlistBtn
            // 
            this.watchlistBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.watchlistBtn.Location = new System.Drawing.Point(1121, 849);
            this.watchlistBtn.Name = "watchlistBtn";
            this.watchlistBtn.Size = new System.Drawing.Size(303, 69);
            this.watchlistBtn.TabIndex = 12;
            this.watchlistBtn.Text = "Add to Watchlist";
            this.watchlistBtn.UseVisualStyleBackColor = true;
            this.watchlistBtn.Visible = false;
            this.watchlistBtn.Click += new System.EventHandler(this.watchlistBtn_Click);
            // 
            // timeLbl
            // 
            this.timeLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.timeLbl.AutoSize = true;
            this.timeLbl.Location = new System.Drawing.Point(725, 720);
            this.timeLbl.Name = "timeLbl";
            this.timeLbl.Size = new System.Drawing.Size(0, 48);
            this.timeLbl.TabIndex = 13;
            this.timeLbl.Visible = false;
            // 
            // timeBox
            // 
            this.timeBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.timeBox.Location = new System.Drawing.Point(447, 788);
            this.timeBox.Name = "timeBox";
            this.timeBox.Size = new System.Drawing.Size(958, 55);
            this.timeBox.TabIndex = 14;
            this.timeBox.Visible = false;
            // 
            // descriptionLbl
            // 
            this.descriptionLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.descriptionLbl.AutoSize = true;
            this.descriptionLbl.BackColor = System.Drawing.Color.Transparent;
            this.descriptionLbl.Location = new System.Drawing.Point(446, 182);
            this.descriptionLbl.Name = "descriptionLbl";
            this.descriptionLbl.Size = new System.Drawing.Size(209, 48);
            this.descriptionLbl.TabIndex = 15;
            this.descriptionLbl.Text = "Description:";
            this.descriptionLbl.Visible = false;
            // 
            // bidLbl
            // 
            this.bidLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bidLbl.AutoSize = true;
            this.bidLbl.Location = new System.Drawing.Point(447, 381);
            this.bidLbl.Name = "bidLbl";
            this.bidLbl.Size = new System.Drawing.Size(208, 48);
            this.bidLbl.TabIndex = 16;
            this.bidLbl.Text = "Current Bid:";
            this.bidLbl.Visible = false;
            // 
            // buyNowLbl
            // 
            this.buyNowLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.buyNowLbl.AutoSize = true;
            this.buyNowLbl.Location = new System.Drawing.Point(446, 490);
            this.buyNowLbl.Name = "buyNowLbl";
            this.buyNowLbl.Size = new System.Drawing.Size(258, 48);
            this.buyNowLbl.TabIndex = 17;
            this.buyNowLbl.Text = "Buy Now Price:";
            this.buyNowLbl.Visible = false;
            // 
            // nameLbl
            // 
            this.nameLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.nameLbl.AutoSize = true;
            this.nameLbl.Location = new System.Drawing.Point(447, 599);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(146, 48);
            this.nameLbl.TabIndex = 18;
            this.nameLbl.Text = "Sold By:";
            this.nameLbl.Visible = false;
            // 
            // timeLbl2
            // 
            this.timeLbl2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.timeLbl2.AutoSize = true;
            this.timeLbl2.Location = new System.Drawing.Point(446, 720);
            this.timeLbl2.Name = "timeLbl2";
            this.timeLbl2.Size = new System.Drawing.Size(284, 48);
            this.timeLbl2.TabIndex = 19;
            this.timeLbl2.Text = "Time Remaining:";
            this.timeLbl2.Visible = false;
            // 
            // userLbl
            // 
            this.userLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.userLbl.AutoSize = true;
            this.userLbl.Location = new System.Drawing.Point(1505, 938);
            this.userLbl.Name = "userLbl";
            this.userLbl.Size = new System.Drawing.Size(350, 48);
            this.userLbl.TabIndex = 20;
            this.userLbl.Text = "You are logged in as:";
            // 
            // usernameLbl
            // 
            this.usernameLbl.AutoSize = true;
            this.usernameLbl.Location = new System.Drawing.Point(1516, 1001);
            this.usernameLbl.Name = "usernameLbl";
            this.usernameLbl.Size = new System.Drawing.Size(58, 48);
            this.usernameLbl.TabIndex = 21;
            this.usernameLbl.Text = "03";
            // 
            // historyLbl
            // 
            this.historyLbl.AutoSize = true;
            this.historyLbl.Location = new System.Drawing.Point(1505, 33);
            this.historyLbl.Name = "historyLbl";
            this.historyLbl.Size = new System.Drawing.Size(293, 48);
            this.historyLbl.TabIndex = 23;
            this.historyLbl.Text = "Purchase History:";
            // 
            // historyData
            // 
            this.historyData.AllowUserToOrderColumns = true;
            this.historyData.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.historyData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.historyData.Location = new System.Drawing.Point(1455, 110);
            this.historyData.Name = "historyData";
            this.historyData.ReadOnly = true;
            this.historyData.RowHeadersWidth = 123;
            this.historyData.RowTemplate.Height = 57;
            this.historyData.Size = new System.Drawing.Size(400, 808);
            this.historyData.TabIndex = 24;
            // 
            // refreshBtn
            // 
            this.refreshBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.refreshBtn.Location = new System.Drawing.Point(725, 967);
            this.refreshBtn.Name = "refreshBtn";
            this.refreshBtn.Size = new System.Drawing.Size(353, 69);
            this.refreshBtn.TabIndex = 25;
            this.refreshBtn.Text = "Refresh";
            this.refreshBtn.UseVisualStyleBackColor = true;
            this.refreshBtn.Click += new System.EventHandler(this.refreshBtn_Click);
            // 
            // watchlistView
            // 
            this.watchlistView.AllowUserToOrderColumns = true;
            this.watchlistView.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.watchlistView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.watchlistView.Location = new System.Drawing.Point(12, 110);
            this.watchlistView.Name = "watchlistView";
            this.watchlistView.ReadOnly = true;
            this.watchlistView.RowHeadersWidth = 123;
            this.watchlistView.RowTemplate.Height = 57;
            this.watchlistView.Size = new System.Drawing.Size(400, 808);
            this.watchlistView.TabIndex = 26;
            // 
            // watchlist_lbl
            // 
            this.watchlist_lbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.watchlist_lbl.AutoSize = true;
            this.watchlist_lbl.Location = new System.Drawing.Point(31, 33);
            this.watchlist_lbl.Name = "watchlist_lbl";
            this.watchlist_lbl.Size = new System.Drawing.Size(346, 48);
            this.watchlist_lbl.TabIndex = 27;
            this.watchlist_lbl.Text = "Your Watched Items:";
            // 
            // supportBtn
            // 
            this.supportBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.supportBtn.Location = new System.Drawing.Point(1104, 969);
            this.supportBtn.Name = "supportBtn";
            this.supportBtn.Size = new System.Drawing.Size(335, 69);
            this.supportBtn.TabIndex = 28;
            this.supportBtn.Text = "Need Support?";
            this.supportBtn.UseVisualStyleBackColor = true;
            this.supportBtn.Click += new System.EventHandler(this.supportBtn_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(20F, 48F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 1067);
            this.Controls.Add(this.supportBtn);
            this.Controls.Add(this.watchlist_lbl);
            this.Controls.Add(this.watchlistView);
            this.Controls.Add(this.refreshBtn);
            this.Controls.Add(this.historyData);
            this.Controls.Add(this.historyLbl);
            this.Controls.Add(this.usernameLbl);
            this.Controls.Add(this.userLbl);
            this.Controls.Add(this.timeLbl2);
            this.Controls.Add(this.nameLbl);
            this.Controls.Add(this.buyNowLbl);
            this.Controls.Add(this.bidLbl);
            this.Controls.Add(this.descriptionLbl);
            this.Controls.Add(this.timeBox);
            this.Controls.Add(this.timeLbl);
            this.Controls.Add(this.watchlistBtn);
            this.Controls.Add(this.buynowBtn);
            this.Controls.Add(this.bidBtn);
            this.Controls.Add(this.sellerName_Box);
            this.Controls.Add(this.buynowBox);
            this.Controls.Add(this.bidBox);
            this.Controls.Add(this.descriptionBox);
            this.Controls.Add(this.productName_Box);
            this.Controls.Add(this.viewallBtn);
            this.Controls.Add(this.listingView_Box);
            this.Controls.Add(this.sellerBtn);
            this.Controls.Add(this.searchbarBtn);
            this.Controls.Add(this.searchbarBox);
            this.MaximizeBox = false;
            this.Name = "Menu";
            this.Text = "Menu";
            ((System.ComponentModel.ISupportInitialize)(this.listingView_Box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.historyData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.watchlistView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox searchbarBox;
        private Button searchbarBtn;
        private Button sellerBtn;
        private DataGridView listingView_Box;
        private Button viewallBtn;
        private TextBox productName_Box;
        private TextBox descriptionBox;
        private TextBox bidBox;
        private TextBox buynowBox;
        private TextBox sellerName_Box;
        private Button bidBtn;
        private Button buynowBtn;
        private Button watchlistBtn;
        private Label timeLbl;
        private TextBox timeBox;
        private Label descriptionLbl;
        private Label bidLbl;
        private Label buyNowLbl;
        private Label nameLbl;
        private Label timeLbl2;
        private Label userLbl;
        private Label usernameLbl;
        private Label historyLbl;
        private DataGridView historyData;
        private Button refreshBtn;
        private DataGridView watchlistView;
        private Label watchlist_lbl;
        private Button supportBtn;
    }
}