﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Auction_System
{
    public partial class SellerMenu : Form
    {
        public string sellername;
        public bool goBack {get;set;}
        public DateTime today = DateTime.Now.Date;
        public CurrencyConverter currency = new CurrencyConverter();
        public Generate generate = new Generate();
        public SellerMenu(string username)
        {
            InitializeComponent();
            sellername = username;
        }

        private void listBtn_Click(object sender, EventArgs e)
        {
            dataController data = new dataController();
            string ticked;
            int error;
            string selection = timeOptions_Box.Text;
            bool valid = validateInputs();
            if (toggleBuynow_checkbox.Checked)
            {
                ticked = "Yes";
            }
            else
            { 
                ticked = "No";
                buynowPrice_Box.Text = "N/A";
            }
            if (int.TryParse(selection, out error))
            {
                if (valid)
                {
                    data.newListing(nameBox.Text, descriptionBox.Text, currency.convert(startbidBox.Text), today, currency.convert(buynowPrice_Box.Text), ticked, sellername, selection, generate.Listing_ID());
                    MessageBox.Show("Listing Created!");
                }
                else
                {
                    MessageBox.Show("Please ensure details are entered correctly!");
                }
            }
            else
            {
                MessageBox.Show("Please select an Auction Duration!");
            }
        }

        private void toggleBuynow_checkbox_CheckedChanged(object sender, EventArgs e)
        {
            if (toggleBuynow_checkbox.Checked == true)
            {
                buynowPrice_Box.Show();
            }
            else
            {
                buynowPrice_Box.Hide();
            }
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Close();
            goBack = true;
        }

        private bool validateInputs()
        {
            int error = 0;
            if(nameBox.Text != null && descriptionBox.Text != null && startbidBox != null)
            {
                if(int.TryParse(startbidBox.Text,out error))
                {
                    if (buynowPrice_Box.Visible == true)
                    {
                        if (int.TryParse(buynowPrice_Box.Text, out error))
                        {
                            return true;
                        }
                        MessageBox.Show("Buy Now price not an integer");
                    }
                }
                MessageBox.Show("Start Bid not an integer");

            }
            MessageBox.Show("All fields not completed");
            return false;
        }
    }
}
