using System;
using System.Net;
using System.Net.Mail;
namespace Auction_System
{
    public partial class Register : Form
    {
        public bool loginscreen { get; set; }
        public string to, from, pass, mail;
        public Generate Gen = new Generate();
        public dataController data = new dataController();
        public string OTP;
        public Register()
        {
            InitializeComponent();
           
        }

        private bool validateInputs()
        {
            if(usernameBox.Text == "" || passwordBox.Text == "" || firstnameBox.Text == "" || lastnameBox.Text == "" || emailBox.Text == "" || addressBox.Text == "")
            {
                MessageBox.Show("Please fill in all fields");
                return false;
            }
            return true;
        }

        private void submitBtn_reg_Click(object sender, EventArgs e)
        {
            if (validateInputs() && validateEmail())
            {
                bool verify = false;
                if (otpBox.Visible == false)
                {
                    MessageBox.Show("If you do not recieve an email within a minute,reload the program or use a valid email address!");
                    otpBox.Show();
                    usernameBox.Hide();
                    passwordBox.Hide();
                    firstnameBox.Hide();
                    lastnameBox.Hide();
                    emailBox.Hide();
                    secondEmailBox.Hide();
                    addressBox.Hide();
                    to = emailBox.Text.ToString();
                    from = "systemauction44@gmail.com";
                    pass = "Creator1";
                    OTP = Gen.Listing_ID().ToString();
                    MailMessage message = new MailMessage();
                    message.To.Add(to);
                    message.From = new MailAddress(from);
                    message.Body = OTP;
                    message.Subject = "One Time Passcode";
                    SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                    smtp.EnableSsl = true;
                    smtp.Port = 587;
                    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential(from, pass);


                    if (smtp != null)
                    {
                        try
                        {
                            smtp.Send(message);
                            MessageBox.Show("Your OTP has been sent to your email!");
                        }

                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: Please enter a valid email address");
                        }
                    }
                }
                int result;
                if (int.TryParse(otpBox.Text, out result))
                {
                    result = int.Parse(otpBox.Text);
                    if (result == int.Parse(OTP))
                    {
                        verify = true;
                    }
                }
                else
                {
                    MessageBox.Show("Not an INTEGER. Try Again;");
                }


                if (verify)
                {
                    data.regData(usernameBox.Text, passwordBox.Text, firstnameBox.Text, lastnameBox.Text, emailBox.Text, addressBox.Text);
                    loginscreen = true;
                    this.Close();
                }


            }
        }

        private bool validateEmail()
        {
            if(emailBox.Text.Contains("@gmail.com"))
            {
                if (emailBox.Text == secondEmailBox.Text)
                { 
                    return true;
                }
                else
                {
                    MessageBox.Show("Emails do not match!");
                }
            }
            MessageBox.Show("Email not in correct format");
            return false;
            
        }

        private void backBtn_reg_Click(object sender, EventArgs e)
        {
            loginscreen = true;
            this.Close();
        }

        private void Register_Load(object sender, EventArgs e)
        {
            MessageBox.Show("We only accept gmail registrations, apologies for any issues");
        }
    }
}