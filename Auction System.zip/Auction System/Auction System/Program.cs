namespace Auction_System
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            newLog();
        }

        public static void newReg()
        {
            Register reg = new Register();
            Application.Run(reg);
            if(reg.loginscreen == true)
            {
                newLog();
            }
        }

        public static void newLog()
        {
            Login log = new Login();
            Application.Run(log);
            if (log.regscreen == true)
            {
                newReg();
            }
            else if (log.menuscreen == true)
            {
                string username = log.username;
                newMenu(username);
            }
            else if (log.adminscreen == true) //WORKING
            {
                newAdmin(); 
            }
            else if(log.support == true)
            {
                newSupport(log.username);
            }
        }

        public static void newMenu(string username)
        {
            Menu menu = new Menu(username);
            Application.Run(menu);
            if(menu.sellerscreen == true)
            {
                newSeller(username);
            }
            else if(menu.refresh == true)
            {
                newMenu(username);
            }
            else if(menu.support == true)
            {
                newSupport(username);
            }
        }

        public static void newSeller(string username)
        {
            SellerMenu seller = new SellerMenu(username);
            Application.Run(seller);
            if(seller.goBack == true)
            {
                newMenu(username);
            }
        }

        public static void newAdmin() 
        {
            AdminMenu Admin = new AdminMenu();
            Application.Run(Admin); 
            if(Admin.refreshpage)
            {
                newAdmin();
            }
        }

        public static void newSupport(string username)
        {
            CustomerSupport support = new CustomerSupport(username);
            Application.Run(support);
        }
    }
}