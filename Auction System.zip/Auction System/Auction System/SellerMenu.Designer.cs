﻿namespace Auction_System
{
    partial class SellerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameBox = new System.Windows.Forms.TextBox();
            this.descriptionBox = new System.Windows.Forms.TextBox();
            this.startbidBox = new System.Windows.Forms.TextBox();
            this.buynowPrice_Box = new System.Windows.Forms.TextBox();
            this.toggleBuynow_checkbox = new System.Windows.Forms.CheckBox();
            this.listBtn = new System.Windows.Forms.Button();
            this.timeOptions_Box = new System.Windows.Forms.ComboBox();
            this.backBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameBox
            // 
            this.nameBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.nameBox.Location = new System.Drawing.Point(34, 38);
            this.nameBox.Name = "nameBox";
            this.nameBox.PlaceholderText = "Item Name";
            this.nameBox.Size = new System.Drawing.Size(597, 55);
            this.nameBox.TabIndex = 0;
            // 
            // descriptionBox
            // 
            this.descriptionBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.descriptionBox.Location = new System.Drawing.Point(34, 117);
            this.descriptionBox.Name = "descriptionBox";
            this.descriptionBox.PlaceholderText = "Description";
            this.descriptionBox.Size = new System.Drawing.Size(597, 55);
            this.descriptionBox.TabIndex = 1;
            // 
            // startbidBox
            // 
            this.startbidBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.startbidBox.Location = new System.Drawing.Point(34, 189);
            this.startbidBox.Name = "startbidBox";
            this.startbidBox.PlaceholderText = "Start Price (In Pennies)";
            this.startbidBox.Size = new System.Drawing.Size(597, 55);
            this.startbidBox.TabIndex = 2;
            // 
            // buynowPrice_Box
            // 
            this.buynowPrice_Box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.buynowPrice_Box.Location = new System.Drawing.Point(34, 345);
            this.buynowPrice_Box.Name = "buynowPrice_Box";
            this.buynowPrice_Box.PlaceholderText = "Buy Now Price(In Pennies)";
            this.buynowPrice_Box.Size = new System.Drawing.Size(597, 55);
            this.buynowPrice_Box.TabIndex = 4;
            this.buynowPrice_Box.Visible = false;
            // 
            // toggleBuynow_checkbox
            // 
            this.toggleBuynow_checkbox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.toggleBuynow_checkbox.AutoSize = true;
            this.toggleBuynow_checkbox.Location = new System.Drawing.Point(34, 416);
            this.toggleBuynow_checkbox.Name = "toggleBuynow_checkbox";
            this.toggleBuynow_checkbox.Size = new System.Drawing.Size(344, 52);
            this.toggleBuynow_checkbox.TabIndex = 5;
            this.toggleBuynow_checkbox.Text = "Buy Now Option?";
            this.toggleBuynow_checkbox.UseVisualStyleBackColor = true;
            this.toggleBuynow_checkbox.CheckedChanged += new System.EventHandler(this.toggleBuynow_checkbox_CheckedChanged);
            // 
            // listBtn
            // 
            this.listBtn.Location = new System.Drawing.Point(153, 474);
            this.listBtn.Name = "listBtn";
            this.listBtn.Size = new System.Drawing.Size(225, 69);
            this.listBtn.TabIndex = 6;
            this.listBtn.Text = "List Item";
            this.listBtn.UseVisualStyleBackColor = true;
            this.listBtn.Click += new System.EventHandler(this.listBtn_Click);
            // 
            // timeOptions_Box
            // 
            this.timeOptions_Box.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.timeOptions_Box.FormattingEnabled = true;
            this.timeOptions_Box.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.timeOptions_Box.Location = new System.Drawing.Point(34, 273);
            this.timeOptions_Box.Name = "timeOptions_Box";
            this.timeOptions_Box.Size = new System.Drawing.Size(597, 56);
            this.timeOptions_Box.TabIndex = 7;
            this.timeOptions_Box.Text = "Auction Length (Days)";
            // 
            // backBtn
            // 
            this.backBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.backBtn.Location = new System.Drawing.Point(1647, 12);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(225, 69);
            this.backBtn.TabIndex = 8;
            this.backBtn.Text = "Back";
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // SellerMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(20F, 48F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 977);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.timeOptions_Box);
            this.Controls.Add(this.listBtn);
            this.Controls.Add(this.toggleBuynow_checkbox);
            this.Controls.Add(this.buynowPrice_Box);
            this.Controls.Add(this.startbidBox);
            this.Controls.Add(this.descriptionBox);
            this.Controls.Add(this.nameBox);
            this.MaximizeBox = false;
            this.Name = "SellerMenu";
            this.Text = "SellerMenu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox nameBox;
        private TextBox descriptionBox;
        private TextBox startbidBox;
        private TextBox buynowPrice_Box;
        private CheckBox toggleBuynow_checkbox;
        private Button listBtn;
        private ComboBox timeOptions_Box;
        private Button backBtn;
    }
}