﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Auction_System
{
    public class CurrencyConverter
    {
        public decimal convert(string text)
        {
            int fallback = 0;
            if(int.TryParse(text, out fallback))
            {
                decimal currency = int.Parse(text) / 100;
                return currency;
            }
            return 0;
        }
    }
}
