﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Auction_System
{
    public class Generate
    {
        public Random rnd = new Random();
        public int Listing_ID()
        {
            string ID = "";
            for(int i = 0; i < 5; i++)
            {
                int num = rnd.Next(0,10);
                if (i == 0 && num == 0)
                {
                    num = rnd.Next(1,10);
                }
                ID = ID + num.ToString();
            }
            return int.Parse(ID);
        }
    }
}
